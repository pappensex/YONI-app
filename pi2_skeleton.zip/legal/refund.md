Refund- / Rückerstattungsregelung

Für digitale Produkte und Services gilt grundsätzlich:  
Eine Rückerstattung nach Bereitstellung des Zugangs oder Downloads ist ausgeschlossen, sofern nicht zwingende gesetzliche Gewährleistungsrechte bestehen.

Ausnahmen können gewährt werden, wenn:  
- es zu technischen Problemen auf unserer Seite kommt,  
- ein bereits bezahlter Zugang nicht bereitgestellt werden kann.

Im Einzelfall kontaktiere uns bitte unter: yoni@pihoch2.me
