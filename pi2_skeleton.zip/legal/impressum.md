Impressum  
Angaben gemäß § 5 TMG

PI² / pihoch2  
Inhaberin: Julia Rappl  
[Anschrift einfügen]

Kontakt:  
E-Mail: yoni@pihoch2.me  
Telefon: +49 152 92611694  

Geschäftskonto:  
N26 Business – IBAN: DE18100110012091876561  

Verantwortlich für den Inhalt nach § 55 Abs. 2 RStV:  
Julia Rappl

Hinweis: Trotz sorgfältiger inhaltlicher Kontrolle übernehmen wir keine Haftung für externe Links. Für Inhalte externer Seiten sind ausschließlich deren Betreiber verantwortlich.
