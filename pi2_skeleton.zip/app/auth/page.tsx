import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { Container } from "@/components/ui/Container";
import { Section } from "@/components/ui/Section";

export default function AuthPage() {
  return (
    <Section>
      <Container className="max-w-md">
        <h1 className="font-display text-2xl mb-4">Anmeldung</h1>
        <p className="text-sm text-black/70 mb-6">
          Dies ist ein Platzhalter für das zukünftige Auth-System. Aktuell
          genügt es, hier deinen Einstieg in PI² zu markieren.
        </p>
        <Card>
          <form className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-black/70 mb-1">
                E-Mail
              </label>
              <input
                type="email"
                className="w-full rounded-xl border border-black/10 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
                placeholder="du@example.com"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-black/70 mb-1">
                Name (optional)
              </label>
              <input
                type="text"
                className="w-full rounded-xl border border-black/10 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
                placeholder="Dein Name"
              />
            </div>
            <Button type="submit" variant="primary" className="w-full">
              Platzhalter-Login
            </Button>
            <p className="text-xs text-black/60">
              Später wird hier ein echtes Login/Signup mit Sessions,
              Stripe-Anbindung und Rollen folgen.
            </p>
          </form>
        </Card>
      </Container>
    </Section>
  );
}
