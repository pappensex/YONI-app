import { NextRequest, NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    items: [
      {
        id: "demo-cashflow-1",
        type: "income",
        amount: 100,
        currency: "EUR",
        description: "Demo-Zahlung"
      }
    ]
  });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  return NextResponse.json({ ok: true, item: body }, { status: 201 });
}
