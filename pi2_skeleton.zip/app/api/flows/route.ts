import { NextRequest, NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    items: [
      {
        id: "demo-flow-1",
        name: "Wenn Rechnung bezahlt → Status aktualisieren"
      }
    ]
  });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  return NextResponse.json({ ok: true, item: body }, { status: 201 });
}
