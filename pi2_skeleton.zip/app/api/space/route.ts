import { NextRequest, NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    items: [
      {
        id: "demo-space-1",
        name: "Wohnzimmer",
        status: "in Bearbeitung"
      }
    ]
  });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  return NextResponse.json({ ok: true, item: body }, { status: 201 });
}
