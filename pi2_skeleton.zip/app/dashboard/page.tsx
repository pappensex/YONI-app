import { Card } from "@/components/ui/Card";
import { Container } from "@/components/ui/Container";
import { Section } from "@/components/ui/Section";

const dashboardModules = [
  {
    key: "CORE",
    title: "CORE",
    summary: "3 Aufgaben heute",
    detail: "Deine wichtigsten Aufgaben, Notizen und Termine an einem Ort."
  },
  {
    key: "FLOW",
    title: "FLOW",
    summary: "Automationen in Vorbereitung",
    detail:
      "Wenn X passiert, dann Y auslösen – wiederkehrende Abläufe ohne Friktion."
  },
  {
    key: "MONEY",
    title: "MONEY",
    summary: "Cashflow Übersicht (Demo)",
    detail:
      "Ein einfacher Blick auf Einnahmen, Ausgaben und Trends – später mit echter Anbindung."
  },
  {
    key: "SPACE",
    title: "SPACE",
    summary: "Bereich: Wohnzimmer – Status: in Bearbeitung",
    detail:
      "Physische und digitale Räume in klare Zonen und Aktionen übersetzen."
  },
  {
    key: "ENERGY",
    title: "ENERGY",
    summary: "Gewohnheit: Fokus 25 min",
    detail:
      "Routinen, die deinen Fokus schützen und dich in den richtigen Modus bringen."
  }
];

export default function DashboardPage() {
  return (
    <Section>
      <Container>
        <h1 className="font-display text-3xl mb-4">Dashboard</h1>
        <p className="text-sm text-black/70 mb-8">
          Diese Ansicht geht davon aus, dass du eingeloggt bist. Die Daten sind
          aktuell noch Platzhalter.
        </p>

        <section className="mb-10">
          <h2 className="font-display text-xl mb-3">Heute</h2>
          <Card>
            <p className="text-sm text-black/80">
              Hier wird später dein täglicher Überblick angezeigt – Aufgaben,
              Fokusslots, Cashflow-Snapshot und relevante Räume.
            </p>
          </Card>
        </section>

        <section>
          <h2 className="font-display text-xl mb-3">Module</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {dashboardModules.map((mod) => (
              <Card key={mod.key}>
                <div className="mb-2 text-xs uppercase tracking-[0.2em] text-black/50">
                  {mod.key}
                </div>
                <h3 className="font-display text-lg mb-1">{mod.title}</h3>
                <p className="text-xs text-primary/80 mb-2">{mod.summary}</p>
                <p className="text-sm text-black/75">{mod.detail}</p>
              </Card>
            ))}
          </div>
        </section>
      </Container>
    </Section>
  );
}
