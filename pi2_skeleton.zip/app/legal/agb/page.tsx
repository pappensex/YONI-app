import { Container } from "@/components/ui/Container";
import { Section } from "@/components/ui/Section";

export default function AgbPage() {
  return (
    <Section>
      <Container className="prose prose-sm max-w-none">
        <h1>Allgemeine Geschäftsbedingungen (AGB)</h1>
        <h2>1. Geltungsbereich</h2>
        <p>
          Diese AGB gelten für alle digitalen Produkte und Dienstleistungen von
          PI² / pihoch2.
        </p>
        <h2>2. Vertragsschluss</h2>
        <p>
          Ein Vertrag kommt zustande, wenn eine Bestellung über unsere
          Plattform erfolgt und wir diese bestätigen bzw. den Zugang
          freischalten.
        </p>
        <h2>3. Preise und Zahlung</h2>
        <p>
          Es gelten die im Bestellprozess angegebenen Preise. Die Zahlung
          erfolgt in der Regel über externe Zahlungsdienstleister (z. B.
          Stripe).
        </p>
        <h2>4. Nutzungsrechte</h2>
        <p>
          Mit vollständiger Bezahlung erhältst du ein einfaches, nicht
          übertragbares Nutzungsrecht an den bereitgestellten digitalen
          Inhalten bzw. Services. Eine Weitergabe oder Vervielfältigung
          außerhalb der vereinbarten Nutzung ist nicht gestattet.
        </p>
        <h2>5. Haftung</h2>
        <p>
          Wir haften nur für Vorsatz und grobe Fahrlässigkeit sowie bei
          Verletzung wesentlicher Vertragspflichten. Eine weitergehende Haftung
          ist ausgeschlossen, soweit nicht zwingende gesetzliche Vorschriften
          entgegenstehen.
        </p>
        <h2>6. Widerruf bei digitalen Inhalten</h2>
        <p>
          Bei digitalen Inhalten erlischt das Widerrufsrecht, wenn wir mit
          deiner ausdrücklichen Zustimmung mit der Ausführung des Vertrages
          begonnen haben und du davon Kenntnis hattest, dass du dein
          Widerrufsrecht mit Beginn der Ausführung verlierst.
        </p>
        <h2>7. Kontakt</h2>
        <p>
          Fragen zum Vertrag oder zu diesen AGB können an folgende Adresse
          gerichtet werden:
          <br />
          E-Mail: <a href="mailto:yoni@pihoch2.me">yoni@pihoch2.me</a>
        </p>
      </Container>
    </Section>
  );
}
