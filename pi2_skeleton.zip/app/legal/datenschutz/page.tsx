import { Container } from "@/components/ui/Container";
import { Section } from "@/components/ui/Section";

export default function DatenschutzPage() {
  return (
    <Section>
      <Container className="prose prose-sm max-w-none">
        <h1>Datenschutzerklärung</h1>
        <p>
          Wir verarbeiten personenbezogene Daten ausschließlich im Einklang mit
          der Datenschutz-Grundverordnung (DSGVO).
        </p>
        <h2>1. Verantwortliche Stelle</h2>
        <p>
          Verantwortlich für die Datenverarbeitung ist:
          <br />
          PI² / pihoch2 – Julia Rappl
          <br />
          E-Mail: <a href="mailto:yoni@pihoch2.me">yoni@pihoch2.me</a>
        </p>
        <h2>2. Arten der verarbeiteten Daten</h2>
        <ul>
          <li>technische Nutzungsdaten (z. B. IP-Adresse, Browser, Gerät, Zeitstempel)</li>
          <li>Kontaktdaten (z. B. E-Mail-Adresse, Name, wenn angegeben)</li>
          <li>Zahlungs- und Abrechnungsdaten (über Zahlungsdienstleister wie Stripe)</li>
        </ul>
        <h2>3. Zwecke der Verarbeitung</h2>
        <ul>
          <li>Betrieb und Sicherheit der Website/App</li>
          <li>Kommunikation mit Nutzer:innen</li>
          <li>Zahlungsabwicklung und Buchhaltung</li>
          <li>Optimierung unseres Angebots</li>
          <li>Erfüllung gesetzlicher Pflichten</li>
        </ul>
        <h2>4. Rechtsgrundlagen</h2>
        <p>Die Verarbeitung erfolgt auf Grundlage von:</p>
        <ul>
          <li>Art. 6 Abs. 1 lit. a DSGVO (Einwilligung)</li>
          <li>Art. 6 Abs. 1 lit. b DSGVO (Vertragserfüllung)</li>
          <li>Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse)</li>
        </ul>
        <h2>5. Cookies und Tracking</h2>
        <p>
          Wir verwenden technisch notwendige Cookies für den Betrieb der
          Website. Analyse- oder Marketing-Cookies kommen nur nach ausdrücklicher
          Einwilligung zum Einsatz.
        </p>
        <h2>6. Weitergabe von Daten</h2>
        <p>
          Eine Weitergabe erfolgt nur, soweit dies zur Vertragserfüllung (z. B.
          Zahlungsdienstleister), zu technischen Zwecken (Hosting) oder aufgrund
          gesetzlicher Pflichten erforderlich ist.
        </p>
        <h2>7. Speicherdauer</h2>
        <p>
          Wir speichern Daten nur so lange, wie es für die jeweiligen Zwecke
          erforderlich ist oder wir gesetzlich dazu verpflichtet sind.
        </p>
        <h2>8. Rechte der Betroffenen</h2>
        <p>Dir stehen folgende Rechte zu:</p>
        <ul>
          <li>Auskunft über die verarbeiteten Daten</li>
          <li>Berichtigung unrichtiger Daten</li>
          <li>Löschung, soweit keine gesetzlichen Aufbewahrungspflichten entgegenstehen</li>
          <li>Einschränkung der Verarbeitung</li>
          <li>Datenübertragbarkeit</li>
          <li>Widerruf erteilter Einwilligungen mit Wirkung für die Zukunft</li>
        </ul>
        <p>
          Zur Ausübung dieser Rechte genügt eine Nachricht an:
          <a href="mailto:yoni@pihoch2.me"> yoni@pihoch2.me</a>
        </p>
      </Container>
    </Section>
  );
}
