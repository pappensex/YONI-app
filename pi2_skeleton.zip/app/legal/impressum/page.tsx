import { Container } from "@/components/ui/Container";
import { Section } from "@/components/ui/Section";

export default function ImpressumPage() {
  return (
    <Section>
      <Container className="prose prose-sm max-w-none">
        <h1>Impressum</h1>
        <p>Angaben gemäß § 5 TMG</p>
        <p>
          PI² / pihoch2
          <br />
          Inhaberin: Julia Rappl
          <br />
          [Anschrift einfügen]
        </p>
        <p>
          <strong>Kontakt:</strong>
          <br />
          E-Mail: <a href="mailto:yoni@pihoch2.me">yoni@pihoch2.me</a>
          <br />
          Telefon: +49 152 92611694
        </p>
        <p>
          <strong>Geschäftskonto:</strong>
          <br />
          N26 Business – IBAN: DE18100110012091876561
        </p>
        <p>
          Verantwortlich für den Inhalt nach § 55 Abs. 2 RStV:
          <br />
          Julia Rappl
        </p>
        <p>
          Hinweis: Trotz sorgfältiger inhaltlicher Kontrolle übernehmen wir keine
          Haftung für externe Links. Für Inhalte externer Seiten sind
          ausschließlich deren Betreiber verantwortlich.
        </p>
      </Container>
    </Section>
  );
}
