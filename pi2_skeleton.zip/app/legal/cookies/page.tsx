import { Container } from "@/components/ui/Container";
import { Section } from "@/components/ui/Section";

export default function CookiesPage() {
  return (
    <Section>
      <Container className="prose prose-sm max-w-none">
        <h1>Cookie-Hinweis</h1>
        <p>
          Wir verwenden Cookies, um unsere Website/App technisch funktionsfähig
          zu betreiben. Bestimmte Cookies sind unbedingt erforderlich, um
          grundlegende Funktionen zur Verfügung zu stellen.
        </p>
        <p>
          Optionale Analyse-Cookies setzen wir nur mit deiner ausdrücklichen
          Einwilligung ein. Die Einwilligung kann jederzeit mit Wirkung für die
          Zukunft widerrufen werden.
        </p>
        <p>
          Der Einsatz von Cookies und die Auswahlmöglichkeiten werden dir in
          unserem Cookie-Banner angezeigt.
        </p>
      </Container>
    </Section>
  );
}
