import { Container } from "@/components/ui/Container";
import { Section } from "@/components/ui/Section";

export default function SecurityPage() {
  return (
    <Section>
      <Container className="prose prose-sm max-w-none">
        <h1>Security / Sicherheit</h1>
        <p>
          Wir betreiben unsere Plattform mit hohen technischen und
          organisatorischen Sicherheitsstandards. Dazu zählen insbesondere:
        </p>
        <ul>
          <li>Verschlüsselung der Datenübertragung (TLS/HTTPS)</li>
          <li>sichere Speicherung von Zugangsdaten (Passwörter nur in gehashter Form)</li>
          <li>Zugriffsbeschränkungen auf Systeme und Daten</li>
          <li>Protokollierung relevanter Systemereignisse</li>
        </ul>
        <p>
          Trotz dieser Maßnahmen kann ein absoluter Schutz vor Angriffen nicht
          garantiert werden. Im Falle einer Sicherheitsverletzung, die
          personenbezogene Daten betrifft, halten wir die gesetzlichen Melde-
          und Informationspflichten ein.
        </p>
      </Container>
    </Section>
  );
}
