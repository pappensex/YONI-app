// Global shared types can live here.
export type TODO = unknown;
