// TODO: Wire up a real database client (e.g. Prisma + PlanetScale/Supabase)
export const db = {};
