"use client";

import { useEffect, useState } from "react";
import { Button } from "../ui/Button";

const STORAGE_KEY = "pi2_cookie_consent";

type ConsentValue = "necessary" | "all";

export function CookieBanner() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      setOpen(true);
    }
  }, []);

  const handleChoice = (value: ConsentValue) => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem(STORAGE_KEY, value);
    }
    setOpen(false);
  };

  if (!open) return null;

  return (
    <div className="fixed inset-x-0 bottom-4 z-40 flex justify_center px-4">
      <div className="max-w-xl rounded-2xl border border-black/10 bg-white shadow-soft px-4 py-3 md:px-6 md:py-4 text-sm text-black/80">
        <p className="mb-3">
          Wir verwenden Cookies für grundlegende Funktionalität und – nur mit
          deiner Zustimmung – für Analyse.
        </p>
        <div className="flex flex-wrap gap-3 justify-end">
          <Button
            variant="secondary"
            onClick={() => handleChoice("necessary")}
          >
            Nur notwendige Cookies
          </Button>
          <Button variant="primary" onClick={() => handleChoice("all")}>
            Alle akzeptieren
          </Button>
        </div>
      </div>
    </div>
  );
}
