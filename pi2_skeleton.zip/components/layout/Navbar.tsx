import Link from "next/link";
import { Container } from "../ui/Container";

export function Navbar() {
  return (
    <header className="border-b border-black/5 bg-white/70 backdrop-blur">
      <Container className="flex items-center justify-between py-4">
        <Link
          href="/"
          className="font-display text-xl tracking-tight text-text"
        >
          PI²
        </Link>
        <nav className="flex items-center gap-4 text-sm text-black/70">
          <Link href="/dashboard" className="hover:text-black">
            Dashboard
          </Link>
          <Link href="/auth" className="hover:text-black">
            Login
          </Link>
        </nav>
      </Container>
    </header>
  );
}
