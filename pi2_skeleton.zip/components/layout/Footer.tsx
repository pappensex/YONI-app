import Link from "next/link";
import { Container } from "../ui/Container";

export function Footer() {
  return (
    <footer className="border-t border-black/5 bg-white mt-16">
      <Container className="flex flex-col gap-4 py-6 text-xs text-black/60 md:flex-row md:items-center md:justify-between">
        <span>© {new Date().getFullYear()} PI² / pihoch2</span>
        <div className="flex flex-wrap gap-4">
          <Link href="/legal/impressum" className="hover:text-black">
            Impressum
          </Link>
          <Link href="/legal/datenschutz" className="hover:text-black">
            Datenschutz
          </Link>
          <Link href="/legal/agb" className="hover:text-black">
            AGB
          </Link>
          <Link href="/legal/cookies" className="hover:text-black">
            Cookies
          </Link>
          <Link href="/legal/security" className="hover:text-black">
            Security
          </Link>
        </div>
      </Container>
    </footer>
  );
}
