"use client";

import React from "react";
import clsx from "clsx";

type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost";
};

export const Button: React.FC<ButtonProps> = ({
  variant = "primary",
  className,
  children,
  ...props
}) => {
  const base =
    "inline-flex items-center justify-center px-4 py-2 text-sm font-medium rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary";

  const variants: Record<string, string> = {
    primary:
      "bg-primary text-white hover:bg-primary/90 focus:ring-primary/50",
    secondary:
      "border border-primary text-primary bg-white hover:bg-primary/5 focus:ring-primary/30",
    ghost: "text-text hover:bg-black/5"
  };

  return (
    <button className={clsx(base, variants[variant], className)} {...props}>
      {children}
    </button>
  );
};
