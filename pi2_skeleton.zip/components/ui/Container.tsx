import React from "react";
import clsx from "clsx";

type ContainerProps = {
  className?: string;
  children: React.ReactNode;
};

export const Container: React.FC<ContainerProps> = ({
  className,
  children
}) => {
  return (
    <div className={clsx("mx-auto max-w-5xl px-4 md:px-6", className)}>
      {children}
    </div>
  );
};
