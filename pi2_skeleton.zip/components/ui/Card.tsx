import React from "react";
import clsx from "clsx";

type CardProps = {
  className?: string;
  children: React.ReactNode;
};

export const Card: React.FC<CardProps> = ({ className, children }) => {
  return (
    <div
      className={clsx(
        "rounded-2xl bg-white shadow-soft border border-black/[0.03] p-6",
        className
      )}
    >
      {children}
    </div>
  );
};
