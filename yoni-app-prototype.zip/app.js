// YONI Control — minimal front‑end prototype (no backend).
// Local-first state
const state = JSON.parse(localStorage.getItem('yoni_state_v1') || '{}')
// defaults
state.todos ??= []
state.activities ??= []
state.assets ??= []
state.papers ??= []
state.notes ??= '<p><b>Start:</b> Schreibe hier Hypothesen, Erkenntnisse, Zitate. Markiere mit <code>#tag</code>.</p>'
state.posts ??= []
state.apps ??= [
  {name:'Notion', url:'https://notion.so'},
  {name:'Figma', url:'https://figma.com'},
  {name:'Drive', url:'https://drive.google.com'},
  {name:'GitHub', url:'https://github.com'},
  {name:'Slack', url:'https://slack.com'}
]
state.brand ??= { color:'#7c3aed', radius:14, blur:8, font:16 }
persist()

// Utilities
function persist(){ localStorage.setItem('yoni_state_v1', JSON.stringify(state)) }
function el(q){ return document.querySelector(q) }
function els(q){ return [...document.querySelectorAll(q)] }
function now(){ return new Date().toISOString() }
function pushActivity(text){ state.activities.unshift({text, ts: now()}); state.activities = state.activities.slice(0,80); persist(); renderFeed() }

// Routing
els('.nav-btn').forEach(b=> b.addEventListener('click', () => {
  els('.nav-btn').forEach(x => x.classList.remove('active'))
  b.classList.add('active')
  const tgt = b.dataset.target
  els('.panel').forEach(p => p.classList.remove('active'))
  el('#'+tgt).classList.add('active')
}))
els('[data-goto]').forEach(b=> b.addEventListener('click', ()=>{
  const tgt = b.getAttribute('data-goto')
  document.querySelector(`.nav-btn[data-target="${tgt}"]`).click()
}))

// Brand system
function applyBrand(){
  document.documentElement.style.setProperty('--brand', state.brand.color)
  document.documentElement.style.setProperty('--radius', state.brand.radius+'px')
  document.documentElement.style.setProperty('--blur', state.brand.blur+'px')
  document.documentElement.style.setProperty('--fontSize', state.brand.font)
}
applyBrand()

// Topbar: theme
let dark = true
el('#themeToggle').addEventListener('click', ()=>{
  dark = !dark
  document.body.style.filter = dark ? 'none' : 'invert(1) hue-rotate(180deg)'
})

// Dashboard To‑dos
function renderTodos(){
  const ul = el('#todayTodos'); ul.innerHTML=''
  state.todos.forEach((t,i)=>{
    const li = document.createElement('li'); li.className='todo-item '+(t.done?'done':'')
    li.innerHTML = `<input type="checkbox" ${t.done?'checked':''} data-i="${i}"> <span>${t.text}</span> <em style="margin-left:auto;opacity:.6">${t.team}</em>`
    ul.appendChild(li)
  })
  ul.addEventListener('change', (e)=>{
    const i = e.target.getAttribute('data-i'); if(i==null) return
    state.todos[i].done = e.target.checked; persist(); renderTodos()
  }, {once:true})
}
el('#addTodo').addEventListener('click', ()=>{
  const text = el('#todoText').value.trim()
  const team = el('#todoTeam').value
  if(!text) return
  state.todos.unshift({text, team, done:false, ts:now()})
  persist(); renderTodos(); pushActivity(`To‑do hinzugefügt: ${text} → ${team}`)
  el('#todoText').value=''
})
renderTodos()

// Activity feed
function renderFeed(){
  const f = el('#activityFeed'); f.innerHTML=''
  state.activities.slice(0,12).forEach(a=>{
    const d = new Date(a.ts).toLocaleString()
    const div = document.createElement('div')
    div.className='item'
    div.textContent = `• ${a.text} — ${d}`
    f.appendChild(div)
  })
}
renderFeed()

// Social mini calendar (placeholder)
function renderMiniCal(){
  const c = el('#socialMini'); c.innerHTML=''
  const days = 14
  for(let i=0;i<days;i++){
    const d = document.createElement('div'); d.className='day'; d.textContent = (i+1)
    c.appendChild(d)
  }
}
renderMiniCal()

// Asset panel (recent)
function renderAssetPanel(){
  const p = el('#assetPanel'); p.innerHTML=''
  state.assets.slice(0,8).forEach((a, idx)=>{
    const d = document.createElement('div'); d.className='asset'; d.textContent = a.name || ('Asset '+(idx+1))
    p.appendChild(d)
  })
}
renderAssetPanel()

// Live translation (stub provider + streaming simulation)
const streamOut = el('#streamOut')
function simulateStream(text){
  streamOut.innerHTML=''
  const words = text.split(' ')
  let i=0
  const int = setInterval(()=>{
    const span = document.createElement('span')
    span.textContent = words[i]+' '
    streamOut.appendChild(span)
    streamOut.scrollTop = streamOut.scrollHeight
    i++
    if(i>=words.length) clearInterval(int)
  }, 40)
}
function translateStub(input, from, to){
  if(!input) return ''
  // naive placeholder "translation" to show UI; replace with API of choice
  if(from==='auto') from='auto'
  return `[${from}→${to}] ${input}`
}
el('#swapLang').addEventListener('click', ()=>{
  const from = el('#fromLang'); const to = el('#toLang'); const tmp = from.value; from.value = to.value; to.value = tmp
})
el('#translateBtn').addEventListener('click', ()=>{
  const text = el('#inputText').value.trim()
  const t = translateStub(text, el('#fromLang').value, el('#toLang').value)
  if(el('#streamToggle').checked){ simulateStream(t) } else { streamOut.textContent = t }
  pushActivity('Übersetzung erzeugt')
  messageFeedPush('user', text)
  messageFeedPush('translator', t)
})
// Voice (best effort, requires HTTPS)
let rec = null, listening=false
el('#micBtn').addEventListener('click', ()=>{
  if('webkitSpeechRecognition' in window){
    if(!rec){
      rec = new webkitSpeechRecognition()
      rec.continuous = true; rec.interimResults = true; rec.lang = 'de-DE'
      rec.onresult = (evt)=>{
        let interim=''; let final=''
        for(let i=evt.resultIndex;i<evt.results.length;i++){
          if(evt.results[i].isFinal) final += evt.results[i][0].transcript
          else interim += evt.results[i][0].transcript
        }
        el('#inputText').value = (final || interim)
      }
      rec.onend = ()=>{ listening=false; el('#voiceStatus').textContent='bereit'; el('#micBtn').textContent='🎤 Live' }
    }
    if(!listening){ rec.start(); listening=true; el('#voiceStatus').textContent='hört zu'; el('#micBtn').textContent='⏸︎ Stop' }
    else { rec.stop(); }
  } else {
    alert('Spracherkennung benötigt Safari/Chrome über HTTPS.')
  }
})

// Bot review & routing (mock logic)
const botReport = el('#botReport')
el('#reviewBtn').addEventListener('click', ()=>{
  const text = el('#inputText').value.trim()
  if(!text){ botReport.textContent='Kein Input.'; return }
  const bots = [...document.querySelectorAll('.bot-toggle:checked')].map(x=>x.dataset.bot)
  const findings = []
  if(bots.includes('guardrail')) findings.push('Guardrail: ✅ ok')
  if(bots.includes('style')) findings.push('Style: ✅ Ton konsistent')
  if(bots.includes('fact')) findings.push('Fact‑Check: ⚠︎ Stub – bitte verifizieren')
  if(bots.includes('route')) findings.push('Router: → Social (Caption erkannt)')
  botReport.innerHTML = findings.map(f=>`<div>• ${f}</div>`).join('')
  pushActivity('Bot‑Check ausgeführt')
  messageFeedPush('bot', 'Review abgeschlossen.')
})
el('#routeBtn').addEventListener('click', ()=>{
  const text = el('#inputText').value.trim()
  const route = 'social'
  pushActivity(`Geroutet an ${route}`)
  messageFeedPush('router', `Nachricht an ${route} gesendet.`)
})

// Message feed
const feed = el('#messageFeed')
function messageFeedPush(who, text){
  const d = document.createElement('div')
  d.className = 'item ' + (who==='user'?'left':'right')
  d.textContent = text
  feed.appendChild(d); feed.scrollTop = feed.scrollHeight
}

// Marketing – Avatar lab
const canvas = el('#avatarCanvas'); const ctx = canvas.getContext('2d')
function drawAvatar(){
  const initials = (el('#avatarInitials').value || 'YN').toUpperCase().slice(0,3)
  const shape = el('#avatarShape').value
  const color = el('#avatarColor').value
  ctx.clearRect(0,0,canvas.width,canvas.height)
  ctx.fillStyle = color
  ctx.strokeStyle = 'rgba(255,255,255,.35)'
  ctx.lineWidth = 2
  ctx.save()
  // shape
  if(shape==='circle'){
    ctx.beginPath(); ctx.arc(128,128,112,0,Math.PI*2); ctx.closePath(); ctx.fill(); ctx.stroke()
  } else if(shape==='squircle'){
    const r=96
    ctx.beginPath()
    for(let a=0;a<2*Math.PI;a+=0.01){
      const x = 128 + Math.pow(Math.cos(a),3)*r
      const y = 128 + Math.pow(Math.sin(a),3)*r
      if(a===0) ctx.moveTo(x,y); else ctx.lineTo(x,y)
    }
    ctx.closePath(); ctx.fill(); ctx.stroke()
  } else if(shape==='hex'){
    const R=110; ctx.beginPath()
    for(let i=0;i<6;i++){ const a = Math.PI/3*i; const x=128+R*Math.cos(a); const y=128+R*Math.sin(a); if(i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y) }
    ctx.closePath(); ctx.fill(); ctx.stroke()
  }
  // initials
  ctx.fillStyle = 'white'
  ctx.font = 'bold 96px Inter, system-ui, -apple-system, Segoe UI, Roboto, sans-serif'
  ctx.textAlign='center'; ctx.textBaseline='middle'
  ctx.fillText(initials, 128, 138)
  ctx.restore()
}
['avatarInitials','avatarShape','avatarColor'].forEach(id=> el('#'+id).addEventListener('input', drawAvatar))
el('#avatarUpload').addEventListener('change', (e)=>{
  const file = e.target.files?.[0]; if(!file) return
  const img = new Image()
  img.onload = ()=>{ ctx.clearRect(0,0,256,256); ctx.drawImage(img,0,0,256,256) }
  img.src = URL.createObjectURL(file)
})
el('#saveAvatar').addEventListener('click', ()=>{
  const url = canvas.toDataURL('image/png')
  const id = 'asset_'+Math.random().toString(36).slice(2,7)
  state.assets.unshift({id, name:'Avatar '+id, url})
  persist(); renderAssetPanel(); renderGallery()
  pushActivity('Avatar als Asset gespeichert')
})
drawAvatar()

// Marketing – brief ideas (mock cards)
el('#briefToIdeas').addEventListener('click', ()=>{
  const brief = el('#marketingBrief').value.trim()
  const ideas = brief ? [
    'Kampagne: "'+brief.slice(0,40)+'…" — 3 Varianten',
    'Hook‑Liste • 10x',
    'Visuelles Moodboard • 1‑Pager'
  ] : ['Kampagnen‑Gerüst', 'Hook‑Liste', 'Visuals‑Moodboard']
  const wrap = el('#ideasList'); wrap.innerHTML=''
  ideas.forEach(t=>{
    const d = document.createElement('div'); d.className='cardlet'; d.textContent = '• '+t; wrap.appendChild(d)
  })
  pushActivity('Marketing‑Ideen generiert (stub)')
})
el('#briefExport').addEventListener('click', ()=>{
  const data = el('#marketingBrief').value
  downloadText('marketing-brief.txt', data || '')
})

// Research – papers
function renderPapers(){
  const ul = el('#paperList'); ul.innerHTML=''
  state.papers.forEach((p,i)=>{
    const li = document.createElement('li'); li.className='paper-item'
    li.innerHTML = `<b>${p.title}</b>  <em style="opacity:.7">#${p.tags.join(',#')}</em>`
    ul.appendChild(li)
  })
}
el('#addPaper').addEventListener('click', ()=>{
  const t = el('#paperTitle').value.trim()
  const tags = el('#paperTags').value.split(',').map(s=>s.trim()).filter(Boolean)
  if(!t) return
  state.papers.unshift({title:t, tags, ts:now()}); persist(); renderPapers()
  el('#paperTitle').value=''; el('#paperTags').value=''
  pushActivity('Paper zur Queue hinzugefügt')
})
renderPapers()

// Research – notes
el('#researchNotes').innerHTML = state.notes
el('#researchNotes').addEventListener('input', ()=>{
  state.notes = el('#researchNotes').innerHTML; persist()
})
el('#notesSummarize').addEventListener('click', ()=>{
  const txt = el('#researchNotes').innerText || ''
  const lines = txt.split(/\n/).filter(Boolean).slice(0,5).map(x=>'• '+x)
  el('#cmdOutput').innerText = 'Zusammenfassung (stub):\n'+lines.join('\n')
  pushActivity('Notizen zusammengefasst (stub)')
})
el('#notesExport').addEventListener('click', ()=>{
  downloadText('research-notes.html', state.notes)
})

// Web – apps
function renderApps(){
  const g = el('#appsGrid'); g.innerHTML=''
  state.apps.forEach(a=>{
    const d = document.createElement('div'); d.className='app-card'
    d.innerHTML = `<b>${a.name}</b><br><a href="${a.url}" target="_blank" rel="noreferrer">${a.url}</a>`
    g.appendChild(d)
  })
}
el('#addApp').addEventListener('click', ()=>{
  const name = el('#appName').value.trim(); const url = el('#appUrl').value.trim()
  if(!name || !url) return
  state.apps.push({name, url}); persist(); renderApps(); pushActivity('App hinzugefügt: '+name)
  el('#appName').value=''; el('#appUrl').value=''
})
renderApps()

// Web – command palette
const palette = {
  '/todo': (args)=>{ state.todos.unshift({text:args.join(' '), team:'General', done:false, ts:now()}); persist(); renderTodos(); return 'To‑do angelegt.' },
  '/post': (args)=>{ const [platform,time,...cap] = args; state.posts.push({platform, time, caption:cap.join(' ')}); persist(); renderPosts(); return 'Post geplant.' },
  '/note': (args)=>{ el('#researchNotes').focus(); document.execCommand('insertText', false, args.join(' ')); return 'Notiz geschrieben.' },
  '/route': (args)=>{ const to = args[0]||'social'; pushActivity('Geroutet per Palette → '+to); return 'Geroutet nach '+to }
}
el('#cmdInput').addEventListener('keydown', (e)=>{
  if(e.key==='Enter'){
    const raw = e.target.value.trim(); e.target.value=''
    const [cmd, ...rest] = raw.split(' ')
    const fn = palette[cmd]; const out = fn? fn(rest) : 'Unbekanntes Kommando'
    const div = document.createElement('div'); div.className='item'; div.textContent = out; el('#cmdOutput').prepend(div)
  }
})

// Creative – gallery
function renderGallery(){
  const g = el('#assetGallery'); g.innerHTML=''
  state.assets.forEach(a=>{
    const d = document.createElement('div'); d.className='img'
    d.innerHTML = `<img src="${a.url||''}" alt="${a.name||''}"><span class="cap">${a.name||''}  <code>#${a.id||''}</code></span>`
    g.appendChild(d)
  })
}
renderGallery()
el('#assetUpload').addEventListener('change', (e)=>{
  const files = [...(e.target.files||[])]
  files.forEach(f=>{
    const reader = new FileReader()
    reader.onload = ()=>{
      const id = 'asset_'+Math.random().toString(36).slice(2,7)
      state.assets.unshift({id, name:f.name, url:reader.result})
      persist(); renderGallery(); renderAssetPanel()
    }
    reader.readAsDataURL(f)
  })
})

// Creative – feedback → tasks
el('#feedbackToTasks').addEventListener('click', ()=>{
  const txt = el('#creativeFeedback').value.trim(); if(!txt) return
  const lines = txt.split('\n').filter(Boolean)
  const ul = el('#creativeTasks'); ul.innerHTML=''
  lines.forEach(line=>{
    const li = document.createElement('li'); li.className='todo-item'
    li.innerHTML = `<input type="checkbox"> <span>${line}</span>`
    ul.appendChild(li)
  })
  pushActivity('Creative‑Feedback in Tasks überführt')
})

// Social – calendar
function renderPosts(){
  const ul = el('#postList'); ul.innerHTML=''
  state.posts.forEach(p=>{
    const li = document.createElement('li'); li.className='paper-item'; li.textContent = `[${p.platform}] ${p.time || ''} — ${p.caption||''}`
    ul.appendChild(li)
  })
}
function renderCalendar(){
  const c = el('#calendar'); c.innerHTML=''
  const nowD = new Date()
  const y = nowD.getFullYear(); const m = nowD.getMonth()
  const first = new Date(y, m, 1).getDay()
  const days = new Date(y, m+1, 0).getDate()
  for(let i=0;i<first;i++){ const d=document.createElement('div'); d.className='slot'; c.appendChild(d) }
  for(let d=1; d<=days; d++){
    const slot = document.createElement('div'); slot.className='slot'
    slot.innerHTML = `<b>${d}</b>`
    const dayStr = `${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`
    state.posts.filter(p=> (p.time||'').startsWith(dayStr)).forEach(p=>{
      const a = document.createElement('a'); a.className='post-pill'; a.textContent = `${p.platform} ${p.time.slice(11,16)} • ${p.caption.slice(0,18)}…`
      slot.appendChild(a)
    })
    c.appendChild(slot)
  }
}
renderPosts(); renderCalendar()
el('#addPost').addEventListener('click', ()=>{
  const d = el('#postDate').value; const t = el('#postTime').value; const plat = el('#postPlatform').value; const cap = el('#postCaption').value
  if(!d || !t || !cap) return
  const time = d+'T'+t
  state.posts.push({platform:plat, time, caption:cap}); persist(); renderPosts(); renderCalendar()
  pushActivity(`Post geplant: ${plat} ${d} ${t}`)
  el('#postCaption').value=''
})

// Settings – brand controls
el('#brandColor').addEventListener('input', (e)=>{ state.brand.color = e.target.value; persist(); applyBrand() })
el('#brandRadius').addEventListener('input', (e)=>{ state.brand.radius = +e.target.value; persist(); applyBrand() })
el('#brandBlur').addEventListener('input', (e)=>{ state.brand.blur = +e.target.value; persist(); applyBrand() })
el('#brandFont').addEventListener('input', (e)=>{ state.brand.font = +e.target.value; persist(); applyBrand() })
el('#resetBrand').addEventListener('click', ()=>{ state.brand = { color:'#7c3aed', radius:14, blur:8, font:16 }; persist(); applyBrand() })

// Data import/export
el('#downloadData').addEventListener('click', ()=>{
  downloadText('yoni-data.json', JSON.stringify(state, null, 2))
})
el('#importBtn').addEventListener('click', ()=> el('#importFile').click())
el('#importFile').addEventListener('change', (e)=>{
  const file = e.target.files?.[0]; if(!file) return
  const reader = new FileReader()
  reader.onload = ()=>{
    try {
      const data = JSON.parse(reader.result)
      Object.assign(state, data); persist(); location.reload()
    } catch(e){ alert('Ungültige JSON.') }
  }
  reader.readAsText(file)
})

// Install prompt (PWA)
let deferredPrompt=null
window.addEventListener('beforeinstallprompt', (e)=>{ e.preventDefault(); deferredPrompt=e; el('#installBtn').style.display='inline-block' })
el('#installBtn').addEventListener('click', async()=>{
  if(deferredPrompt){ deferredPrompt.prompt(); deferredPrompt=null }
})

// Register SW
el('#registerSW').addEventListener('click', async()=>{
  if('serviceWorker' in navigator){
    await navigator.serviceWorker.register('./sw.js')
    alert('Offline‑Modus aktiviert.')
  } else alert('Service Worker nicht unterstützt.')
})

// Export helper
function downloadText(filename, text) {
  const blob = new Blob([text], {type: 'text/plain'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

// Keyboard: Command Palette
document.addEventListener('keydown', (e)=>{
  if((e.metaKey||e.ctrlKey) && e.key.toLowerCase()==='k'){ e.preventDefault(); el('#cmdInput').focus() }
})

// Search jump (simple)
el('#search').addEventListener('keydown', (e)=>{
  if(e.key==='Enter'){
    const q = e.target.value.toLowerCase()
    const map = {live:'translate', marketing:'marketing', research:'research', web:'web', creative:'creative', social:'social', settings:'settings'}
    for(const k in map){ if(q.includes(k)){ document.querySelector(`.nav-btn[data-target="${map[k]}"]`).click(); break } }
  }
})
