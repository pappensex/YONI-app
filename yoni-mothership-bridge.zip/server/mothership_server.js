import 'dotenv/config';
import express from 'express';
import OpenAI from 'openai';
import fetch from 'node-fetch';
import pino from 'pino';

const log = pino({ level: process.env.LOG_LEVEL || 'info' });
const app = express();
app.use(express.json({ limit: '2mb' }));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const PORT = process.env.PORT || 8787;
const YONI_AGENT_URL = process.env.YONI_AGENT_URL || 'http://127.0.0.1:5055';

// --- Tool/Function catalog exposed to GPT‑5 ---
const tools = [
  {
    type: "function",
    function: {
      name: "yoni_get_status",
      description: "Liefert einen kompakten Systemstatusbericht von YONI (CPU, RAM, Uptime, Netz).",
      parameters: {
        type: "object",
        properties: {},
        additionalProperties: false
      }
    }
  },
  {
    type: "function",
    function: {
      name: "yoni_list_assets",
      description: "Listet bekannte Assets/Sensoren/Aktoren von YONI. Optional nach Typ filtern.",
      parameters: {
        type: "object",
        properties: {
          kind: { type: "string", enum: ["sensor", "actuator", "virtual"], nullable: true }
        },
        additionalProperties: false
      }
    }
  },
  {
    type: "function",
    function: {
      name: "yoni_read_sensor",
      description: "Liest einen Sensorwert von YONI (nur whitelisted IDs).",
      parameters: {
        type: "object",
        properties: {
          sensor_id: { type: "string" }
        },
        required: ["sensor_id"],
        additionalProperties: false
      }
    }
  }
];

// Delegates tool execution to YONI agent via HTTP
async function callYoniTool(fnName, args) {
  const url = `${YONI_AGENT_URL}/tool/${fnName}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(args || {}),
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error(`YONI tool ${fnName} failed: ${res.status} ${t}`);
  }
  return await res.json();
}

// Minimal chat endpoint illustrating function calling round‑trip
app.post('/chat', async (req, res) => {
  const user = (req.body && req.body.user) || "Sag Hallo zu YONI.";
  const system = (req.body && req.body.system) || "Du bist das Mutterschiff. Sei präzise und benutze Tools nur wenn nötig.";
  const messages = [
    { role: "system", content: system },
    { role: "user", content: user }
  ];

  try {
    // First turn: let GPT‑5 decide whether to call a tool
    let completion = await client.chat.completions.create({
      model: "gpt-5", // GPT‑5 Pro
      messages,
      tools,
      tool_choice: "auto",
      temperature: 0.2
    });

    // Process tool calls (could be multiple)
    let toolMessages = [];
    const first = completion.choices[0];
    const toolCalls = first.message.tool_calls || [];

    for (const call of toolCalls) {
      const { function: { name, arguments: argStr } } = call;
      let args = {};
      try { args = argStr ? JSON.parse(argStr) : {}; } catch (e) { args = {}; }
      log.info({ tool: name, args }, "Executing YONI tool");

      const toolResult = await callYoniTool(name, args);
      toolMessages.push(
        { role: "tool", tool_call_id: call.id, name, content: JSON.stringify(toolResult) }
      );
    }

    // If tools were used, follow‑up completion to produce final answer
    if (toolMessages.length > 0) {
      completion = await client.chat.completions.create({
        model: "gpt-5",
        messages: [...messages, first.message, ...toolMessages],
        temperature: 0.2
      });
    }

    const finalText = completion.choices[0].message.content;
    res.json({ ok: true, text: finalText, raw: completion });
  } catch (err) {
    log.error(err);
    res.status(500).json({ ok: false, error: String(err) });
  }
});

app.get('/healthz', (_, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  log.info(`Mutterschiff online at http://localhost:${PORT}`);
});
