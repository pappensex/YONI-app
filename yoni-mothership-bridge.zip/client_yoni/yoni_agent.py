from flask import Flask, request, jsonify
import psutil, os, time, socket

app = Flask(__name__)

# Simple in-memory assets catalog
ASSETS = {
    "sensor:cpu_temp": {"kind": "sensor", "name": "CPU Temperature (mock)", "unit": "°C"},
    "sensor:cpu_load": {"kind": "sensor", "name": "CPU Load", "unit": "%"},
    "sensor:mem_used": {"kind": "sensor", "name": "Memory Used", "unit": "MB"},
}

def get_status():
    boot = psutil.boot_time()
    uptime_s = int(time.time() - boot)
    vm = psutil.virtual_memory()
    net = psutil.net_io_counters()
    cpu = psutil.cpu_percent(interval=0.2)
    return {
        "host": socket.gethostname(),
        "uptime_seconds": uptime_s,
        "cpu_percent": cpu,
        "ram_percent": vm.percent,
        "ram_used_mb": int((vm.total - vm.available) / (1024*1024)),
        "net_bytes_sent": net.bytes_sent,
        "net_bytes_recv": net.bytes_recv,
    }

@app.post("/tool/yoni_get_status")
def tool_get_status():
    return jsonify(get_status())

@app.post("/tool/yoni_list_assets")
def tool_list_assets():
    data = request.get_json(silent=True) or {}
    kind = data.get("kind")
    items = [
        {"id": k, **v} for k, v in ASSETS.items() if (kind is None or v.get("kind") == kind)
    ]
    return jsonify({"assets": items})

@app.post("/tool/yoni_read_sensor")
def tool_read_sensor():
    data = request.get_json(silent=True) or {}
    sensor_id = data.get("sensor_id")
    if sensor_id not in ASSETS:
        return jsonify({"error": "unknown sensor_id"}), 400
    if sensor_id == "sensor:cpu_load":
        value = psutil.cpu_percent(interval=0.2)
    elif sensor_id == "sensor:mem_used":
        vm = psutil.virtual_memory()
        value = int((vm.total - vm.available) / (1024*1024))
    elif sensor_id == "sensor:cpu_temp":
        # Mock if sensors not available
        value = 42.0
    else:
        value = None
    return jsonify({"sensor_id": sensor_id, "value": value, "unit": ASSETS[sensor_id]["unit"]})

@app.get("/healthz")
def healthz():
    return jsonify({"ok": True})

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5055)
