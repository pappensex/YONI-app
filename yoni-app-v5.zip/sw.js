self.addEventListener('install', (e)=>{ self.skipWaiting() })
self.addEventListener('activate', (e)=>{ self.clients.claim() })
self.addEventListener('fetch', (e)=>{
  if(e.request.method!=='GET') return
  e.respondWith((async()=>{
    const cache = await caches.open('yoni-v5')
    const cached = await cache.match(e.request)
    if(cached) return cached
    const res = await fetch(e.request).catch(()=>null)
    if(res && res.status===200){ cache.put(e.request, res.clone()) }
    return res || new Response('',{status:200})
  })())
})
