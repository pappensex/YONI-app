// YONI v5 — Creator‑KI + Auto‑Translate + Transzendenz (iPhone‑first)
const SKEY = 'yoni_state_v5'
const state = JSON.parse(localStorage.getItem(SKEY) || '{}')
state.todos ??= []
state.activities ??= []
state.assets ??= []
state.brand ??= { color:'#7c3aed', radius:14, blur:8, font:16 }
state.translate ??= { auto:true, to:'de', raw:false }
state.creator ??= { voice:'authority', claim:'Pro. Präzise. Premium. Perfekt.', deepprompt:'' }
persist()

function persist(){ localStorage.setItem(SKEY, JSON.stringify(state)) }
function now(){ return new Date().toISOString() }
function el(q){ return document.querySelector(q) }
function els(q){ return [...document.querySelectorAll(q)] }
function pushActivity(text){ state.activities.unshift({text, ts: now()}); state.activities = state.activities.slice(0,120); persist(); renderActivity() }

// Env hint (file vs. https)
function showEnvHint(){
  const hint = el('#envAlert')
  if(!hint) return
  if(location.protocol === 'file:'){
    hint.textContent = 'Datei‑Modus: Installieren/Offline sind eingeschränkt. Für PWA bitte HTTPS‑URL nutzen.'
  } else { hint.textContent = '' }
}
showEnvHint()

// Brand
function applyBrand(){
  document.documentElement.style.setProperty('--brand', state.brand.color)
  document.documentElement.style.setProperty('--radius', state.brand.radius+'px')
  document.documentElement.style.setProperty('--blur', state.brand.blur+'px')
  document.documentElement.style.setProperty('--fontSize', state.brand.font)
}
applyBrand()

// Routing
els('.nav-btn').forEach(b=> b.addEventListener('click', () => {
  els('.nav-btn').forEach(x => x.classList.remove('active'))
  b.classList.add('active')
  const tgt = b.dataset.target
  els('.panel').forEach(p => p.classList.remove('active'))
  el('#'+tgt).classList.add('active')
  if(tgt==='assets') renderGallery()
}))
els('[data-goto]').forEach(b=> b.addEventListener('click', ()=>{
  const tgt = b.getAttribute('data-goto')
  document.querySelector(`.nav-btn[data-target="${tgt}"]`).click()
}))

// Topbar
let dark = true
el('#themeToggle').addEventListener('click', ()=>{
  dark = !dark
  document.body.style.filter = dark ? 'none' : 'invert(1) hue-rotate(180deg)'
})
document.addEventListener('keydown', (e)=>{
  if((e.metaKey||e.ctrlKey) && e.key.toLowerCase()==='k'){ e.preventDefault(); el('#search').focus() }
})
el('#search').addEventListener('keydown', (e)=>{
  if(e.key==='Enter'){
    const q = e.target.value.toLowerCase()
    const map = {creator:'creator', transzendenz:'transcend', live:'translate', assets:'assets', settings:'settings'}
    for(const k in map){ if(q.includes(k)){ document.querySelector(`.nav-btn[data-target="${map[k]}"]`).click(); break } }
  }
})

// Dashboard
function renderCounters(){
  el('#autoTStatus').textContent = state.translate.auto ? 'aktiv' : 'aus'
  el('#agentCount').textContent = 4
  el('#assetCount').textContent = state.assets.length
}
function renderTodos(){
  const ul = el('#todayTodos'); if(!ul) return
  ul.innerHTML=''
  state.todos.forEach((t,i)=>{
    const li = document.createElement('li'); li.className='todo-item '+(t.done?'done':'')
    li.innerHTML = `<input type="checkbox" ${t.done?'checked':''} data-i="${i}"> <span>${t.text}</span> <em style="margin-left:auto;opacity:.6">${t.team||'General'}</em>`
    ul.appendChild(li)
  })
  ul.addEventListener('change', (e)=>{
    const i = e.target.getAttribute('data-i'); if(i==null) return
    state.todos[i].done = e.target.checked; persist(); renderTodos()
  }, {once:true})
}
el('#addTodo')?.addEventListener('click', ()=>{
  const text = el('#todoText').value.trim()
  const team = el('#todoTeam').value
  if(!text) return
  state.todos.unshift({text, team, done:false, ts:now()})
  persist(); renderTodos(); renderCounters(); pushActivity(`To‑do: ${text} → ${team}`)
  el('#todoText').value=''
})
function renderActivity(){
  const f = el('#activityFeed'); if(!f) return; f.innerHTML=''
  state.activities.slice(0,12).forEach(a=>{
    const d = new Date(a.ts).toLocaleString()
    const div = document.createElement('div')
    div.className='item'
    div.textContent = `• ${a.text} — ${d}`
    f.appendChild(div)
  })
}
renderCounters(); renderTodos(); renderActivity()

// Creator‑KI
el('#brandColor').value = state.brand.color
el('#brandRadius').value = state.brand.radius
el('#brandBlur').value = state.brand.blur
el('#brandFont').value = state.brand.font
el('#voicePreset').value = state.creator.voice
el('#toneClaim').value = state.creator.claim
el('#deepprompt').value = state.creator.deepprompt
el('#brandColor').addEventListener('input', (e)=>{ state.brand.color = e.target.value; persist(); applyBrand() })
el('#brandRadius').addEventListener('input', (e)=>{ state.brand.radius = +e.target.value; persist(); applyBrand() })
el('#brandBlur').addEventListener('input', (e)=>{ state.brand.blur = +e.target.value; persist(); applyBrand() })
el('#brandFont').addEventListener('input', (e)=>{ state.brand.font = +e.target.value; persist(); applyBrand() })
el('#voicePreset').addEventListener('change', (e)=>{ state.creator.voice = e.target.value; persist() })
el('#toneClaim').addEventListener('input', (e)=>{ state.creator.claim = e.target.value; persist() })
el('#deepprompt').addEventListener('input', (e)=>{ state.creator.deepprompt = e.target.value; persist() })
el('#creatorRender').addEventListener('click', ()=>{
  const txt = el('#creatorInput').value.trim() || 'Wir liefern. Pro. Präzise. Premium. Perfekt.'
  const rendered = renderCreator(txt)
  el('#creatorOut').innerHTML = rendered
  pushActivity('Creator‑KI gerendert')
})
el('#exportCreator').addEventListener('click', ()=>{
  const cfg = JSON.stringify({brand:state.brand, creator:state.creator, translate:state.translate}, null, 2)
  downloadText('yoni-creator-config.json', cfg)
})
el('#importCreatorBtn').addEventListener('click', ()=> el('#importCreator').click())
el('#importCreator').addEventListener('change', (e)=>{
  const file = e.target.files?.[0]; if(!file) return
  const reader = new FileReader()
  reader.onload = ()=>{
    try {
      const data = JSON.parse(reader.result)
      if(data.brand) state.brand = data.brand
      if(data.creator) state.creator = data.creator
      if(data.translate) state.translate = data.translate
      persist(); location.reload()
    } catch(err){ alert('Ungültige JSON.') }
  }
  reader.readAsText(file)
})
function renderCreator(text){
  const v = state.creator.voice
  const claim = state.creator.claim || ''
  const pre = {
    authority: (s)=> `<div><b>Authority</b> • ${claim}</div><div style="margin-top:6px">${s}</div>`,
    muse: (s)=> `<div><i>Muse</i> • ${claim}</div><div style="margin-top:6px">${s}</div>`,
    engineer: (s)=> `<div><b>Engineer</b> • ${claim}</div><div style="margin-top:6px"><code>${s}</code></div>`,
    zen: (s)=> `<div><b>Zen</b> • ${claim}</div><div style="margin-top:6px">${s}</div>`,
  }[v] || ((s)=>s)
  return pre(text)
}

// Transzendenz
el('#tTargetLabel').textContent = langName(state.translate.to)
el('#prefLang').value = state.translate.to
el('#prefAuto').checked = state.translate.auto
el('#prefRaw').checked = state.translate.raw
el('#tAuto').checked = state.translate.auto
el('#tRaw').checked = state.translate.raw
el('#prefLang').addEventListener('change', (e)=>{ state.translate.to = e.target.value; persist(); el('#tTargetLabel').textContent = langName(state.translate.to) })
el('#prefAuto').addEventListener('change', (e)=>{ state.translate.auto = e.target.checked; persist(); renderCounters() })
el('#prefRaw').addEventListener('change', (e)=>{ state.translate.raw = e.target.checked; persist() })
el('#tAuto').addEventListener('change', (e)=>{ state.translate.auto = e.target.checked; persist(); renderCounters() })
el('#tRaw').addEventListener('change', (e)=>{ state.translate.raw = e.target.checked; persist() })

el('#tAsk')?.addEventListener('click', ()=>{
  const q = el('#tInput').value.trim(); if(!q) return
  const selected = els('.agent:checked').map(a=>a.value)
  const mode = el('#fusionMode').value
  const answers = selected.map(a=>({agent:a, text: agentAnswer(a, q)}))
  const fused = fuseAnswers(answers, mode)
  const out = el('#tOut')
  ;[{agent:'Fusion', text:fused}, ...answers].forEach(item=>{
    const div = document.createElement('div'); div.className='item'
    div.innerHTML = `<b>${label(item.agent)}</b>: ${sanitize(maybeTranslate(item.text))}`
    out.prepend(div)
  })
  pushActivity(`Fusion‑Antwort (${mode})`)
})
el('#tClear')?.addEventListener('click', ()=>{ el('#tOut').innerHTML='' })

function agentAnswer(agent, q){
  const base = `Antwort auf „${q}“ — `
  switch(agent){
    case 'gpt': return base + 'präzise, strukturiert, mit Handlungsempfehlung.'
    case 'chi-alpha': return base + 'intuitiv, visionär, poetisch‑kantig.'
    case 'chi-beta': return base + 'technisch, datengetrieben, scharf.'
    case 'chi-omega': return base + 'synthetisch, meta, systemisch.'
    default: return base + 'neutral.'
  }
}
function fuseAnswers(arr, mode){
  if(mode==='consensus') return 'Konsens: ' + arr.map(a=>a.text).join(' | ')
  if(mode==='contrast') return 'Kontrast: ' + arr.map(a=>a.text).join(' ⇄ ')
  if(mode==='chain') return 'Chain: ' + arr.map((a,i)=>`[${i+1}] ${a.text}`).join(' → ')
  return arr.map(a=>a.text).join('\n')
}
function label(agent){
  return ({
    'gpt':'GPT‑5 Pro',
    'chi-alpha':'CHIBot‑Alpha',
    'chi-beta':'CHIBot‑Beta',
    'chi-omega':'CHIBot‑Omega'
  })[agent] || agent
}
function sanitize(s){ return s.replace(/[<>&]/g, c=> ({'<':'&lt;','>':'&gt;','&':'&amp;'}[c])) }
function langName(code){ return ({de:'Deutsch',en:'English',fr:'Français',es:'Español',it:'Italiano'})[code] || code }

// Live‑Übersetzung
el('#swapLang').addEventListener('click', ()=>{
  const from = el('#fromLang'); const to = el('#toLang'); const tmp = from.value; from.value = to.value; to.value = tmp
})
el('#translateBtn').addEventListener('click', ()=>{
  const text = el('#inputText').value.trim()
  const t = translateStub(text, el('#toLang').value, el('#cleanMode').checked)
  el('#streamOut').textContent = t
})
let rec = null, listening=false
el('#micBtn').addEventListener('click', ()=>{
  // iOS Safari hat kein webkitSpeechRecognition; Workaround: iOS‑Diktierfunktion in Tastatur nutzen.
  alert('Hinweis: iOS Safari unterstützt Mikrofondiktat über die Tastatur (Diktier‑Taste).')
})

// Translation stubs + global
function translateStub(text, to='de', clean=true){
  if(!text) return ''
  const prefix = clean ? '' : '[RAW] '
  return prefix + text // später via API ersetzen
}
function maybeTranslate(text){
  if(!state.translate.auto) return text
  return translateStub(text, state.translate.to, !state.translate.raw)
}

// Assets
el('#assetUpload').addEventListener('change', (e)=>{
  const files = [...(e.target.files||[])]
  files.forEach(f=>{
    const reader = new FileReader()
    reader.onload = ()=>{
      const id = 'asset_'+Math.random().toString(36).slice(2,7)
      state.assets.unshift({id, name:f.name, url:reader.result})
      persist(); renderGallery(); renderCounters()
    }
    reader.readAsDataURL(f)
  })
})
function renderGallery(){
  const g = el('#assetGallery'); if(!g) return; g.innerHTML=''
  state.assets.forEach(a=>{
    const d = document.createElement('div'); d.className='img'
    d.innerHTML = `<img src="${a.url||''}" alt="${a.name||''}"><span class="cap">${a.name||''}  <code>#${a.id||''}</code></span>`
    g.appendChild(d)
  })
}

// Settings — data + SW
el('#downloadData').addEventListener('click', ()=>{
  downloadText('yoni-data.json', JSON.stringify(state, null, 2))
})
el('#importBtn').addEventListener('click', ()=> el('#importFile').click())
el('#importFile').addEventListener('change', (e)=>{
  const file = e.target.files?.[0]; if(!file) return
  const reader = new FileReader()
  reader.onload = ()=>{
    try {
      const data = JSON.parse(reader.result)
      Object.assign(state, data); persist(); location.reload()
    } catch(e){ alert('Ungültige JSON.') }
  }
  reader.readAsText(file)
})
el('#registerSW').addEventListener('click', async()=>{
  if(location.protocol!=='https:'){ alert('Service Worker benötigt HTTPS. Lade die App über eine HTTPS‑URL und versuche es erneut.'); return }
  if('serviceWorker' in navigator){
    await navigator.serviceWorker.register('./sw.js')
    alert('Offline‑Modus aktiviert.')
  } else alert('Service Worker nicht unterstützt.')
})

// Helpers
function downloadText(filename, text) {
  const blob = new Blob([text], {type: 'text/plain'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}
